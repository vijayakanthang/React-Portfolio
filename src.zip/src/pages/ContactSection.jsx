import { useEffect, useState } from "react";
import emailjs from "emailjs-com";
import GithubWidget from "../components/GithubWidget";
import { contactCommands, profile } from "../data/siteContent";

const initialFormState = {
  name: "",
  email: "",
  message: "",
};

const statusMessages = {
  idle: "$ ready_to_send.sh",
  sending: "Sending...",
  success: "Sending... Delivered!",
  error: "[error] Message delivery failed. Please mail me directly.",
};

export default function ContactSection() {
  const [formData, setFormData] = useState(initialFormState);
  const [status, setStatus] = useState("idle");
  const [statusText, setStatusText] = useState(statusMessages.idle);

  useEffect(() => {
    const target = statusMessages[status];
    let index = 0;
    setStatusText("");

    const timer = window.setInterval(() => {
      index += 1;
      setStatusText(target.slice(0, index));
      if (index >= target.length) {
        window.clearInterval(timer);
      }
    }, 18);

    return () => window.clearInterval(timer);
  }, [status]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus("sending");

    try {
      await emailjs.send(
        "service_5rzlekg",
        "template_sjlowzo",
        {
          name: formData.name,
          email: formData.email,
          subject: `Portfolio contact from ${formData.name}`,
          message: formData.message,
        },
        "VE82rDWI2NKcKIQpY",
      );
      setFormData(initialFormState);
      setStatus("success");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="contact" className="page-section section section--contact">
      <div className="section-shell contact-shell">
        <div className="contact-left">
          <p className="section-eyebrow mono">Contact</p>
          <h2>LET&apos;S BUILD SOMETHING</h2>
          <p className="contact-subtitle">Currently open to product-focused engineering roles.</p>

          <div className="contact-command-list">
            {contactCommands.map((command) => (
              <a key={command.label} href={command.href} target="_blank" rel="noreferrer">
                <span className="mono">{command.label}</span>
                <span>{command.value}</span>
              </a>
            ))}
          </div>

          <GithubWidget username={profile.githubUsername} />
        </div>

        <div className="contact-right terminal-window">
          <div className="terminal-window__header">
            <div className="terminal-dots">
              <span />
              <span />
              <span />
            </div>
            <span className="terminal-window__title">contact@vijayakanthan:~</span>
          </div>

          <form className="terminal-form" onSubmit={handleSubmit}>
            <label>
              <span className="mono">&gt; enter_name:</span>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Your name"
              />
            </label>
            <label>
              <span className="mono">&gt; enter_email:</span>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                placeholder="you@example.com"
              />
            </label>
            <label>
              <span className="mono">&gt; enter_message:</span>
              <textarea
                name="message"
                rows="6"
                value={formData.message}
                onChange={handleChange}
                required
                placeholder="Tell me about your product or role."
              />
            </label>
            <button type="submit" className="button button--primary">
              $ send_message.sh
            </button>
          </form>

          <p className={`terminal-status terminal-status--${status} mono`}>{statusText}</p>
        </div>
      </div>
    </section>
  );
}
