import { useEffect, useMemo, useRef, useState } from "react";
import { SiLeetcode } from "react-icons/si";
import { codingProfile } from "../data/siteContent";

const LEETCODE_API = "https://leetcode-stats-api.herokuapp.com/vijayakanthan";

export default function LeetcodeSection() {
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const [stats, setStats] = useState({
    isLoading: true,
    hasError: false,
    data: null,
  });

  useEffect(() => {
    let cancelled = false;

    async function loadStats() {
      try {
        const response = await fetch(LEETCODE_API);
        if (!response.ok) throw new Error("Failed to load LeetCode stats");
        const data = await response.json();

        if (!cancelled) {
          setStats({
            isLoading: false,
            hasError: false,
            data,
          });
        }
      } catch {
        if (!cancelled) {
          setStats({
            isLoading: false,
            hasError: true,
            data: null,
          });
        }
      }
    }

    loadStats();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!sectionRef.current) return undefined;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.35 },
    );

    observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const ringData = useMemo(() => {
    if (!stats.data) return [];
    const total = Math.max(1, stats.data.totalSolved || 1);

    return [
      {
        label: "Easy",
        value: stats.data.easySolved || 0,
        color: "#4ade80",
        percent: ((stats.data.easySolved || 0) / total) * 100,
      },
      {
        label: "Medium",
        value: stats.data.mediumSolved || 0,
        color: "#facc15",
        percent: ((stats.data.mediumSolved || 0) / total) * 100,
      },
      {
        label: "Hard",
        value: stats.data.hardSolved || 0,
        color: "#ef4444",
        percent: ((stats.data.hardSolved || 0) / total) * 100,
      },
    ];
  }, [stats.data]);

  return (
    <section id="leetcode" ref={sectionRef} className="page-section section section--leetcode">
      <div className="section-shell">
        <article className="leetcode-card">
          <div className="leetcode-card__header">
            <p className="section-eyebrow mono">
              <SiLeetcode /> LeetCode
            </p>
            <h3>@{codingProfile.username}</h3>
            <p>DSA practice profile</p>
          </div>

          {!stats.hasError && stats.data ? (
            <div className="leetcode-stats">
              <p className="leetcode-total mono">Total Solved: {stats.data.totalSolved}</p>
              <div className="leetcode-rings">
                {ringData.map((ring) => (
                  <div key={ring.label} className="leetcode-ring-card">
                    <div
                      className="leetcode-ring"
                      style={{
                        "--ring-color": ring.color,
                        "--pct": isVisible ? ring.percent : 0,
                      }}
                    >
                      <span>{ring.value}</span>
                    </div>
                    <p className="mono">{ring.label}</p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="leetcode-fallback">
              <p className="mono">{stats.isLoading ? "Loading stats..." : "Stats unavailable right now"}</p>
              <div className="coding-profile-card__chips">
                {codingProfile.focus.map((item) => (
                  <span key={item} className="project-tech-pill">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          )}

          <a href={codingProfile.url} target="_blank" rel="noreferrer" className="button button--ghost">
            View LeetCode Profile
          </a>
        </article>
      </div>
    </section>
  );
}

