import { useEffect, useMemo, useState } from "react";
import { gsap } from "gsap";
import { profile } from "../data/siteContent";
import { useMotionPreferences } from "../hooks/useMotionPreferences";
import { useScrollScene } from "../hooks/useScrollScene";

export default function AboutSection() {
  const { isDesktop, prefersReducedMotion } = useMotionPreferences();
  const usePinnedScene = isDesktop && !prefersReducedMotion;

  const words = useMemo(() => profile.about.join(" ").split(" "), []);
  const statTargets = useMemo(
    () => profile.quickStats.map((item) => Number.parseInt(item.value.replace(/[^\d]/g, ""), 10)),
    [],
  );
  const statStarts = useMemo(() => statTargets.map((value) => (value >= 2000 ? 2020 : 0)), [statTargets]);

  const [countValues, setCountValues] = useState(statTargets);

  const { ref, tl, isReady } = useScrollScene({
    scrubSpeed: 1.3,
    end: "+=150%",
    disabled: !usePinnedScene,
  });

  useEffect(() => {
    if (!usePinnedScene || !isReady || !tl.current || !ref.current) {
      setCountValues(statTargets);
      return undefined;
    }

    const ctx = gsap.context(() => {
      const timeline = tl.current;
      const counterState = { progress: 0 };
      timeline.clear();

      timeline
        .fromTo(
          ".about-heading",
          { opacity: 0, letterSpacing: "0.5em" },
          { opacity: 1, letterSpacing: "-0.02em", duration: 0.34 },
          0.02,
        )
        .fromTo(
          ".about-word",
          { opacity: 0, y: 10 },
          { opacity: 1, y: 0, stagger: 0.02, duration: 0.22 },
          0.28,
        )
        .fromTo(
          ".about-stat-card",
          { opacity: 0, y: 24 },
          { opacity: 1, y: 0, stagger: 0.05, duration: 0.2 },
          0.54,
        )
        .to(
          counterState,
          {
            progress: 1,
            duration: 0.18,
            onUpdate: () => {
              const current = statTargets.map((target, index) =>
                Math.round(gsap.utils.interpolate(statStarts[index], target, counterState.progress)),
              );
              setCountValues(current);
            },
          },
          0.56,
        )
        .fromTo(".about-education-card", { opacity: 0, y: 32 }, { opacity: 1, y: 0, duration: 0.2 }, 0.72);
    }, ref);

    return () => ctx.revert();
  }, [isReady, ref, statStarts, statTargets, tl, usePinnedScene]);

  return (
    <section id="about" ref={ref} className="page-section section section--about scene-shell">
      <div className="section-shell about-shell">
        <p className="section-eyebrow mono">About</p>
        <h2 className="about-heading">ABOUT ME</h2>

        <p className="about-word-line">
          {words.map((word, index) => (
            <span key={`${word}-${index}`} className="about-word">
              {word}
            </span>
          ))}
        </p>

        <div className="quick-stats-grid about-stats-grid">
          {profile.quickStats.map((stat, index) => (
            <article key={stat.label} className="about-stat-card">
              <span className="quick-stat-card__value">{countValues[index]}</span>
              <span className="quick-stat-card__label">{stat.label}</span>
              <p>{stat.detail}</p>
            </article>
          ))}
        </div>

        <article className="about-education-card">
          <p className="card-label mono">Education</p>
          <h3>{profile.education.degree}</h3>
          <p>{profile.education.school}</p>
          <p className="muted">{profile.education.meta}</p>
        </article>
      </div>
    </section>
  );
}
