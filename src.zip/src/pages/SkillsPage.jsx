import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import RadarChart from "../components/RadarChart";
import { skillGroups, skillOverview } from "../data/siteContent";

const SkillsOrbitCanvas = lazy(() => import("../components/SkillsOrbitCanvas"));

export default function SkillsPage() {
  const sectionRef = useRef(null);
  const [shouldRenderScene, setShouldRenderScene] = useState(false);
  const [hoveredSkill, setHoveredSkill] = useState(null);

  const rings = useMemo(() => {
    const frontend = skillGroups.find((group) => group.title === "Frontend");
    const backend = skillGroups.find((group) => group.title === "Backend");
    const cloud = skillGroups.find((group) => group.title.includes("Cloud"));
    const tools = skillGroups.find((group) => group.title.includes("Tools"));

    const ringThreeNames = ["Azure", "Git", "Vercel", "JWT Authentication", "REST APIs"];
    const ringThreeSource = [...(cloud?.items || []), ...(tools?.items || [])];

    return [
      {
        title: "Frontend",
        color: "#00d4ff",
        radius: 2,
        speed: 0.003,
        items: (frontend?.items || []).slice(0, 5).map((name) => ({ name, detail: "Frontend stack" })),
      },
      {
        title: "Backend",
        color: "#4ade80",
        radius: 3.5,
        speed: 0.002,
        items: (backend?.items || []).slice(0, 5).map((name) => ({ name, detail: "Backend platform" })),
      },
      {
        title: "ToolsCloud",
        color: "#f59e0b",
        radius: 5,
        speed: 0.001,
        items: ringThreeNames.map((name) => ({ name, detail: "Tools and cloud workflow" })).filter((item) =>
          ringThreeSource.some((sourceItem) => sourceItem === item.name),
        ),
      },
    ];
  }, []);

  useEffect(() => {
    if (!sectionRef.current || shouldRenderScene) return undefined;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShouldRenderScene(true);
          observer.disconnect();
        }
      },
      { rootMargin: "180px 0px" },
    );

    observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, [shouldRenderScene]);

  return (
    <section id="skills" ref={sectionRef} className="page-section section section--skills">
      <div className="section-shell">
        <p className="section-eyebrow mono">Skills</p>
        <h2 className="section-title">
          Orbital capability map around a <span className="accent">single builder core</span>.
        </h2>

        <div className="skills-orbit-panel">
          {shouldRenderScene ? (
            <Suspense fallback={<div className="canvas-placeholder" />}>
              <SkillsOrbitCanvas rings={rings} onHoverDetail={setHoveredSkill} />
            </Suspense>
          ) : (
            <div className="canvas-placeholder" />
          )}

          <div className="skills-hover-card">
            <p className="mono">{hoveredSkill?.label || "Hover a node"}</p>
            <p>{hoveredSkill?.detail || "Orbit pauses and detail expands when you hover a skill."}</p>
          </div>
        </div>

        <div className="skills-radar-panel">
          <RadarChart categories={skillOverview} />
        </div>
      </div>
    </section>
  );
}
