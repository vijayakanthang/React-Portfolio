import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { FaBriefcase } from "react-icons/fa";
import { experiences } from "../data/siteContent";
import { useMotionPreferences } from "../hooks/useMotionPreferences";
import { useScrollScene } from "../hooks/useScrollScene";

export default function ExperiencePage() {
  const { isDesktop, prefersReducedMotion } = useMotionPreferences();
  const usePinnedScene = isDesktop && !prefersReducedMotion;
  const connectorRef = useRef(null);

  const { ref, tl, isReady } = useScrollScene({
    scrubSpeed: 1.25,
    end: "+=180%",
    disabled: !usePinnedScene,
  });

  useEffect(() => {
    if (!usePinnedScene || !isReady || !tl.current || !ref.current) return undefined;

    const ctx = gsap.context(() => {
      const timeline = tl.current;
      const connector = connectorRef.current;
      const pathLength = connector?.getTotalLength() || 0;

      if (connector) {
        connector.style.strokeDasharray = `${pathLength}`;
        connector.style.strokeDashoffset = `${pathLength}`;
      }

      timeline.clear();
      timeline
        .fromTo(".experience-field", { xPercent: 0 }, { xPercent: -8, duration: 1 }, 0)
        .fromTo(".exp-card--0", { scale: 0.95, opacity: 0.6 }, { scale: 1.05, opacity: 1, duration: 0.34 }, 0.05)
        .fromTo(
          ".exp-card--0 .experience-point",
          { x: -24, opacity: 0 },
          { x: 0, opacity: 1, stagger: 0.06, duration: 0.18 },
          0.16,
        )
        .fromTo(
          connectorRef.current,
          { strokeDashoffset: pathLength },
          { strokeDashoffset: 0, duration: 0.25 },
          0.45,
        )
        .fromTo(".exp-card--1", { scale: 0.95, opacity: 0.6 }, { scale: 1.05, opacity: 1, duration: 0.34 }, 0.68)
        .fromTo(
          ".exp-card--1 .experience-tech-pill",
          { y: 20, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.05, duration: 0.2 },
          0.8,
        );
    }, ref);

    return () => ctx.revert();
  }, [isReady, ref, tl, usePinnedScene]);

  return (
    <section id="experience" ref={ref} className="page-section section section--experience scene-shell">
      <div className="section-shell">
        <p className="section-eyebrow mono">Experience</p>
        <h2 className="section-title">
          Product execution across <span className="accent">frontend quality</span> and cloud security.
        </h2>

        <div className="experience-stage">
          <div className="experience-field" aria-hidden="true" />

          <svg className="experience-connector-svg" viewBox="0 0 1000 220" aria-hidden="true">
            <path ref={connectorRef} d="M 220 118 C 380 95, 620 145, 780 118" className="experience-connector-path" />
          </svg>

          <div className="experience-cards">
            {experiences.map((experience, index) => (
              <article
                key={experience.company}
                className={`exp-card exp-card--${index} exp-card--${experience.tone}`}
              >
                <div className="exp-card__topline">
                  <span className={`exp-card__badge ${experience.badge === "Current Role" ? "is-pulsing" : ""}`}>
                    {experience.badge}
                  </span>
                  <span className="exp-card__company mono">
                    <FaBriefcase />
                    {experience.company}
                  </span>
                </div>

                <h3>{experience.role}</h3>
                <p className="exp-card__meta mono">
                  {experience.duration} | {experience.location}
                </p>

                <ul className="experience-points">
                  {experience.details.map((detail) => (
                    <li key={detail} className="experience-point">
                      {detail}
                    </li>
                  ))}
                </ul>

                <div className="experience-tech">
                  {experience.tech.map((item) => (
                    <span key={item} className="experience-tech-pill">
                      {item}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
