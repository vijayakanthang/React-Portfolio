import { lazy, Suspense, useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { gsap } from "gsap";
import { FaEnvelope, FaGithub, FaLinkedinIn } from "react-icons/fa";
import { SiLeetcode } from "react-icons/si";
import { availabilityChips, heroTerminalLines, profile } from "../data/siteContent";
import { useMotionPreferences } from "../hooks/useMotionPreferences";
import { useScrollScene } from "../hooks/useScrollScene";

const HeroCanvas = lazy(() => import("../components/HeroCanvas"));
const MotionDiv = motion.div;

export default function HeroSection() {
  const { isDesktop, prefersReducedMotion } = useMotionPreferences();
  const usePinnedScene = isDesktop && !prefersReducedMotion;
  const [typedText, setTypedText] = useState("");
  const [isComplete, setIsComplete] = useState(false);
  const [shouldRenderCanvas, setShouldRenderCanvas] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  const { ref, tl, isReady } = useScrollScene({
    scrubSpeed: 1.5,
    end: "+=170%",
    disabled: !usePinnedScene,
    onUpdate: setScrollProgress,
  });

  const titleChars = useMemo(() => profile.name.split(""), []);

  useEffect(() => {
    if (!ref.current || shouldRenderCanvas) return undefined;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShouldRenderCanvas(true);
          observer.disconnect();
        }
      },
      { rootMargin: "220px 0px" },
    );

    observer.observe(ref.current);
    return () => observer.disconnect();
  }, [shouldRenderCanvas, ref]);

  useEffect(() => {
    const script = (isDesktop ? heroTerminalLines.desktop : heroTerminalLines.mobile).join("\n");
    let index = 0;

    setTypedText("");
    setIsComplete(false);

    const timer = window.setInterval(() => {
      index += 1;
      setTypedText(script.slice(0, index));
      if (index >= script.length) {
        window.clearInterval(timer);
        setIsComplete(true);
      }
    }, isDesktop ? 22 : 16);

    return () => window.clearInterval(timer);
  }, [isDesktop]);

  useEffect(() => {
    if (!usePinnedScene || !isReady || !tl.current || !ref.current) return undefined;

    const ctx = gsap.context(() => {
      const timeline = tl.current;
      timeline.clear();

      timeline
        .fromTo(".hero-dot", { opacity: 0, scale: 0.2 }, { opacity: 1, scale: 1, duration: 0.28 }, 0)
        .fromTo(
          ".hero-title-char",
          { opacity: 0, y: 54, filter: "blur(8px)" },
          { opacity: 1, y: 0, filter: "blur(0px)", stagger: 0.03, duration: 0.46 },
          0.08,
        )
        .fromTo(".hero-subtitle", { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: 0.35 }, 0.24)
        .to(".hero-title", { xPercent: -30, opacity: 0.2, duration: 0.32 }, 0.42)
        .fromTo(".hero-terminal", { xPercent: 24, opacity: 0 }, { xPercent: 0, opacity: 1, duration: 0.36 }, 0.42)
        .fromTo(
          ".hero-chip-row .hero-chip",
          { opacity: 0, y: -26 },
          { opacity: 1, y: 0, stagger: 0.05, duration: 0.24 },
          0.55,
        )
        .fromTo(
          ".hero-socials a",
          { opacity: 0, y: 22, scale: 0.86 },
          { opacity: 1, y: 0, scale: 1, stagger: 0.05, duration: 0.22 },
          0.62,
        )
        .fromTo(".hero-grid-overlay", { opacity: 0 }, { opacity: 0.48, duration: 0.25 }, 0.72)
        .fromTo(".hero-cta-wrap", { opacity: 0, y: 15 }, { opacity: 1, y: 0, duration: 0.3 }, 0.76)
        .fromTo(".hero-scroll-indicator", { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.28 }, 0.84);
    }, ref);

    return () => ctx.revert();
  }, [isReady, ref, tl, usePinnedScene]);

  return (
    <section id="home" ref={ref} className="page-section hero-section scene-shell">
      {shouldRenderCanvas ? (
        <Suspense fallback={<div className="canvas-placeholder hero-canvas-placeholder" />}>
          <HeroCanvas scrollProgress={scrollProgress} />
        </Suspense>
      ) : (
        <div className="canvas-placeholder hero-canvas-placeholder" />
      )}

      <div className="hero-grid-overlay" aria-hidden="true" />
      <div className="section-shell hero-shell">
        <div className="hero-copy">
          <div className="hero-dot" aria-hidden="true" />
          <h1 className="hero-title">
            {titleChars.map((char, index) => (
              <span key={`${char}-${index}`} className="hero-title-char">
                {char === " " ? "\u00A0" : char}
              </span>
            ))}
          </h1>
          <p className="hero-subtitle mono">{profile.roleStack}</p>
          <p className="hero-description">
            Frontend-focused engineer building polished web experiences with React, Next.js, and
            TypeScript.
          </p>

          <div className="hero-chip-row">
            {availabilityChips.map((chip) => (
              <span key={chip} className="hero-chip">
                {chip}
              </span>
            ))}
          </div>

          <div className="hero-socials">
            <a href={profile.github} target="_blank" rel="noreferrer" aria-label="GitHub">
              <FaGithub />
            </a>
            <a href={profile.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <FaLinkedinIn />
            </a>
            <a href={profile.leetcode} target="_blank" rel="noreferrer" aria-label="LeetCode">
              <SiLeetcode />
            </a>
            <a href={`mailto:${profile.email}`} aria-label="Email">
              <FaEnvelope />
            </a>
          </div>
        </div>

        <MotionDiv
          className="terminal-window hero-terminal"
          drag={!prefersReducedMotion && isDesktop}
          dragElastic={0.12}
          dragMomentum={false}
        >
          <div className="terminal-window__header">
            <div className="terminal-dots">
              <span />
              <span />
              <span />
            </div>
            <span className="terminal-window__title">session@portfolio:~</span>
            <span className="terminal-window__hint">drag me</span>
          </div>

          <pre className="terminal-window__body">
            {typedText}
            <span className="terminal-cursor">_</span>
          </pre>

          <MotionDiv
            className="terminal-window__footer hero-cta-wrap"
            initial={{ opacity: 0, y: 12 }}
            animate={isComplete ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 }}
          >
            <a className="button button--primary" href="#projects">
              View My Work -&gt;
            </a>
            <a className="button button--ghost" href={profile.resume} target="_blank" rel="noreferrer">
              Download Resume
            </a>
          </MotionDiv>
        </MotionDiv>
      </div>
      <p className="hero-scroll-indicator mono">v SCROLL TO EXPLORE</p>
    </section>
  );
}
