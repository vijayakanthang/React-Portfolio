import ProjectScrollScene from "../components/ProjectScrollScene";
import { projects } from "../data/siteContent";

export default function ProjectsSection() {
  return (
    <section id="projects" className="page-section section section--projects">
      <div className="section-shell">
        <p className="section-eyebrow mono">Projects</p>
        <h2 className="section-title">
          Scroll-driven product reveals with <span className="accent">one scene per project</span>.
        </h2>
      </div>

      <div className="projects-scenes">
        {projects.map((project, index) => (
          <ProjectScrollScene key={project.slug} project={project} index={index} />
        ))}
      </div>
    </section>
  );
}
