import { FaArrowRight } from "react-icons/fa";
import { certifications } from "../data/siteContent";

export default function CertificationsPage() {
  return (
    <section id="certifications" className="page-section section section--certifications">
      <div className="section-shell">
        <p className="section-eyebrow mono">Certifications</p>
        <h2 className="section-title">
          Verified credentials with a <span className="accent">flip-to-verify</span> interaction.
        </h2>

        <div className="certifications-grid">
          {certifications.map((item) => (
            <article key={item.title} className="cert-card">
              <div className="cert-card__inner">
                <div className="cert-face cert-face--front">
                  <span className="cert-issuer-pill mono">{item.issuer}</span>
                  <p className="cert-platform mono">{item.platform}</p>
                  <h3>{item.title}</h3>
                  <p className="credential-id mono">ID: {item.credentialId}</p>
                </div>

                <div className="cert-face cert-face--back">
                  <p>{item.summary}</p>
                  <a href={item.url} target="_blank" rel="noreferrer" className="inline-link">
                    Verify Certificate
                    <FaArrowRight />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
